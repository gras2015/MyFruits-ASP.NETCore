# Création d'une application web avec ASP.NET Core Razor Pages et Entity Framework Core
 
### YouTube

[![Vidéo](https://i3.ytimg.com/vi/QjQ5_Lw5urc/maxresdefault.jpg)](https://www.youtube.com/watch?v=QjQ5_Lw5urc)
