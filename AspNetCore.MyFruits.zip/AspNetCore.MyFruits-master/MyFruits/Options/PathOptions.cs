﻿namespace MyFruits.Options;

public class PathOptions
{
    public const string Path = "Path";

    public string FruitsImages { get; set; } = string.Empty;
}
